import cv2 as cv

class attributs():

    couleur_moyenne=0
    nom=""
    dim=0

    def __init__(self,nom):
        #constructeur
        self.nom=nom
        self.set_Taille()

#setteurs
    def set_Taille(self):

        image = cv.imread(self.nom)
        self.dim = image.shape

    def set_couleur_moyenne(self,nmb):
        self.couleur_moyenne=nmb