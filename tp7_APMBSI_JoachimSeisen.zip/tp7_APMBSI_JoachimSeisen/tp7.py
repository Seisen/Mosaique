import cv2 as cv
import Attributs_image as attImg 
import math
import os
import random


liste_images=[]



#fonction ayant comme parametres la video et le nombres de sec entre chaque image recupéré et qui retourne le nombres d'images
def get_images_from_video(vid,toutLesXsec):
    listeIndicesImg=[]#liste des indices

    video = cv.VideoCapture(vid)
    #on recupere le nombres de frame
    nmbrFrame = video.get(cv.CAP_PROP_FRAME_COUNT)
    #on recupere le nombre de FPS
    nmbrFrameParSec = video.get(cv.CAP_PROP_FPS)
    
    #on transforme les valeurs en entiers pour eviter une errueur dans la boucle
    nmbrFrame=int(nmbrFrame)
    nmbrFrameParSec=int(nmbrFrameParSec)

    cptNumImage=0#numero de l'image

    #for qui recupere l'indice de l'image tout les x secs (nombre de FPS * x secs)

    for i in range(1,nmbrFrame,int(nmbrFrameParSec*toutLesXsec)):
        listeIndicesImg+=[i]#implementation dans la liste

    #for qui recupere  les images correspondants aux indices dans la liste
    for i in range(0,nmbrFrame):
        reussi,image = video.read()
        
        #si la liste est vide alors on a recuperé toutes nos images
        if len(listeIndicesImg)==0:
            print("Terminé !")
            break

        #si l'indice i est egal au premier indice de la liste
        if i==listeIndicesImg[0]:
            listeIndicesImg.pop(0)#on supprime cette indice
            if reussi:
                cv.imwrite("img/image%d.jpg" % cptNumImage, image)#on ajoute l'image dans le dossier image avec son numero

                print("importation de l'image ",str(cptNumImage),"... ("+str(int(i*100/nmbrFrame))+"%)")

                cptNumImage+=1#on indente le numero

    return cptNumImage


def convert_all_imgs_inAFolder(dimX,dimY,nombreImage):

    for i in range(0,nombreImage):
        # lis l'image
        image = cv.imread('img/image'+str(i)+'.jpg')
        # resize l'image
        image = cv.resize(image,(dimX,dimY))
        #enregistre l'image
        cv.imwrite("img2/image%d.jpg" % i, image)#on ajoute l'image dans le dossier image avec son numero
        print("image" ,str(i)," converti avec succes !")
        

def calcul_couleur_moyenne(image,taille):
    r,g,b=(0,0,0)
    for i in range(taille):
        for j in range(taille):
            r0,g0,b0=image[i,j]

            r+=r0
            g+=g0
            b+=b0
            #on fait la somme

    #on calcule la moyenne

    r/=(taille*taille)
    g/=(taille*taille)
    b/=(taille*taille)

    couleur_moy=(int(r),int(g),int(b))

    return couleur_moy



def couleur_moyenne(img,liste_images,taille):

    #on ajoute l'objet a la liste
    liste_images+=[attImg.attributs(img)]

    #on definit le dernier indice pour rendre le code plus clair
    dernierIndice=len(liste_images)-1

    # on recupere les dimenssions
    dimX,dimY,z=liste_images[dernierIndice].dim

    #on lit l'image
    image =cv.imread(img)
    couleur_moy = calcul_couleur_moyenne(image,taille)
    
    #on set l'objet
    liste_images[dernierIndice].set_couleur_moyenne(couleur_moy)

def set_liste_images(liste_images,nombreImage,taille):
    #execute couleur moyenne pour toute les images du dossier image2
    for i in range(nombreImage):
        couleur_moyenne('img2/image'+str(i)+'.jpg',liste_images,taille)

        print("calculs de la couleur moyenne de l'image ",str(i)," ...")

def get_nmbr_Ligne_Colonne(taille):
    image=cv.imread('imageRef/image_reference.jpg')
    x,y,z = image.shape

    x1=int(x/taille)
    y1=int(y/taille)
    return x1,y1


def indice_image_plus_proche(couleur,liste_images,bool,taux_diversité):
    r,g,b=couleur
    plus_proche=0
    
    liste_plus_proche=[]

    #boucle qui tourne jusqua que la taille de la liste de choix dimage la plus proche n'est pas egal au taux entr
    while len(liste_plus_proche)<taux_diversité:
        score=1000000
        for i in range(len(liste_images)):#on parcour la liste d'image
            #on recupere la couleur de l'image d'indice i
            r1,b1,g1=liste_images[i].couleur_moyenne
            #pour calculer le score on fait la somme de la valeur absolue de la soustraction des couleurs donc plus ce sera proche de zero plus la couleur sera proche
            score1=abs(r-r1)+abs(g-g1)+abs(b-b1)
            #si bool est vrai on creer la liste proche
            if (i not in liste_plus_proche):#si i est dans la liste on ne le test pas
                if score1<score  and  bool:#on compare avec le meilleur score et si c'est vrai
                    
                    score=score1#devient le nouveau score
                    plus_proche=i   #on sauvegarde l'indice

            if score1<score and not bool:
                score=score1
                plus_proche=i   
        
        liste_plus_proche+=[plus_proche]#on ajoute le plus proche dans la liste

    rng=random.randint(0,len(liste_plus_proche)-1)#on creer un nombre aleatoire comprit entre zero et la taille de la liste

    return liste_plus_proche[rng]#on retourne le plus proche d'indice aleatoire

def ajouteImage(image,liste_images,indice,x,y,taille):
    image2=cv.imread(liste_images[indice].nom)
    
    for i in range(0,taille):
        
        for j in range(0,taille):
            
            image[i+x,j+y]=image2[i,j]
    return image



def creer_mosaique(nmbrLignes,nmbreColonnes,liste_images,taille,bool,taux_diversité):
    
    image = cv.imread('imageRef/image_reference.jpg')

    image2 =cv.resize(image,(nmbrLignes,nmbreColonnes))
    #on parcour l'image reduit
    for i in range(0,nmbrLignes):
        for j in range(0,nmbreColonnes):
            #on recupere l'indice de l'image a copié
            indice=indice_image_plus_proche(image2[i,j],liste_images,bool,taux_diversité)
            #on copie l'image
            image=ajouteImage(image,liste_images,indice,i*taille,j*taille,taille)

            print("creation de la mosaique...")
            print("cela peut prendre quelques minutes ...")
            print("avancement ",int((i)*100/nmbrLignes)," %")
            
    cv.imwrite("imageFinal.jpg", image)

#MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN__MAIN
nmbr_img=0

var=int(input("Si vous avez importé une banque d'images dans img entrez 0 sinon si vous avez importé une video dans videos entrez 1  et 2 si vous avez deja converti les images ou la vidéo auparavant : "))
if var==0:#si on veut les images d'une video
    #on converti la videos en image
    FichiersDossier = os.listdir("videos")  # pour récupérer le nom des fichiers du dossier
    for i in range (len(FichiersDossier)):
        nmbr_img+=get_images_from_video('videos/'+FichiersDossier[i],2)
elif var==2:#si la banque est deja initialisé on ne fait rien
    nmbr_img= len(os.listdir("img"))
    
else:#on converti le noms des fichiers
    FichiersDossier = os.listdir("img")  # pour récupérer le nom des fichiers du dossier
    for i in range(len(FichiersDossier)):
        print("renomage de l'image" ,FichiersDossier[i])
        os.rename(FichiersDossier[i],'image'+str(i)+'.jpg') 


print("_____________________________________________________________________________")

taille=int(input("Entrez la taille des petites images (exemple 10 , 20 , 30 ...) : " ))
#on converti les images par rapport a la taille
convert_all_imgs_inAFolder(taille,taille,nmbr_img)
print("_____________________________________________________________________________")
taille_image=int(input("Entrez la taille de l'image final (exemple 1000 pour 1000x1000) : "))#on recup la taille

imgRef= os.listdir("imageRef")#on recupere limage de reference
nomImageRef=imgRef[0] 

image = cv.imread('imageRef/'+nomImageRef)
image =cv.resize(image,(taille_image,taille_image))

cv.imwrite('imageRef/image_reference.jpg', image)

set_liste_images(liste_images,nmbr_img,taille)#on creer et on rempli la liste d'objets image

L,C=get_nmbr_Ligne_Colonne(taille)#on recupere le nmbre de ligne et de colonne
print("_____________________________________________________________________________")
diversifier=bool(input("Entrez True si vous voulez diversifier les pixels (augmentent considerablement le temps de calcul) sinon entrez False , n'oubliez pas la majuscule! : "))

print("_____________________________________________________________________________")
if diversifier:
    taux_diversité=int(input("Entrez le taux de diversité (de 1 à 40) : "))
else:
    taux_diversité=1
print("_____________________________________________________________________________")
creer_mosaique(L,C,liste_images,taille,diversifier,taux_diversité)
print("Terminé !")



